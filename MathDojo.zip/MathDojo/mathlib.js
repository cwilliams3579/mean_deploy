module.exports = function(){
    return {
        add: function(num1, num2){
            console.log(num1 + num2, "Is the addition of 10 + 10!");
        },
        multiply: function(num1, num2){
            console.log(num1 * num2, "Is 10 multipled by 10!");
        },
        square: function(num1){
            console.log(num1 * num1, "Is the square of 9!");
        },
        random: function(num1, num2) {
            console.log(Math.floor(Math.random() * num2) * num1, "A random number between 1-35");
        }
    }
}
