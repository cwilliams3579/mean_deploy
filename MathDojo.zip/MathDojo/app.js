var mathlib = require('./mathlib')();  
mathlib.add(10,10);
mathlib.multiply(10,10);
mathlib.square(9);
mathlib.random(1,35);