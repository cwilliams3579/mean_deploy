var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://localhost/mongoose_dashboard');
var RabbitSchema = new mongoose.Schema({
 name: String,
 age: Number
})
mongoose.model('rabbit', RabbitSchema);
var Rabbit = mongoose.model('rabbit')

app.get('/', function(req, res) {
    Rabbit.find({}, function(err, rabbits){
      if(err){
        console.log("Something went wrong");
      }
      else{
        console.log("found rabbits successfully");
        console.log(rabbits);
        res.render('index', {rabbits:rabbits});
      }
    })
});

app.get('/rabbit/new', function(req, res){
  console.log("am I hitting the new route???");
  res.render('new');
});

app.post('/rabbits', function(req, res) {
  console.log("POST DATA", req.body);
  var rabbit = new Rabbit({name: req.body.name, age: req.body.age});
  console.log(rabbit);
  rabbit.save(function(err) {
    if(err) {
      console.log('What the heck did i break now');
    } else {
      console.log('successfully added a rabbit!');
      res.redirect('/');
    }
  })
});

app.get('/rabbit/:id/edit', function(req, res){
  Rabbit.findOne({_id:req.params.id}, function(err, rabbit){
    if(err){
      console.log("rabbit/:id/edit error ", err);
    }
    else{
      res.render('edit',{rabbit:rabbit});
    }
  })
});

app.post('/rabbits/:id/update', function(req, res) {
  console.log("POST DATA", req.body);
  Rabbit.findOne({_id:req.params.id}, function(err, rabbit){
    rabbit.name = req.body.name;
    rabbit.age = req.body.age;
    console.log(rabbit.name, " is the new name");
    console.log(rabbit.age, " is the new age");
    rabbit.save(function(err) {
      if(err) {
        console.log('something went wrong');
      }
      else {
        console.log('successfully updated a rabbit!');
        console.log(rabbit);
        res.redirect('/');
      }
    })
  })
});

app.post('/rabbits/:id/destroy', function(req, res){
  Rabbit.remove({_id:req.params.id}, function(err, rabbit){
    if(err){
      console.log("rabbits/:id/destroy error ", err);
    }
    else{
      console.log("Please don't delete the cute rabbit ", req.params.id);
      res.redirect('/');
    }
  })
});

app.get('/rabbit/:id', function(req, res){
  Rabbit.findOne({_id:req.params.id}, function(err, rabbit){
    if(err){
      console.log("rabbit/:id error ", err);
    }
    else{
      res.render('show',{rabbit:rabbit});
    }
  })
});

app.listen(6789, function() {
    console.log("listening on port 6789");
})
