function runningLogger(){
  
  console.log("I am running!");
  
}
runningLogger();


function multipyByTen(x){
	return x*10;
};
console.log(multipyByTen(5));




function stringReturnOne(){
	var x = "Teenage Mutant";
	return x;
};
function stringReturnTwo(){
	var y = "Ninja Turtles";
	return y;
}
console.log(stringReturnOne());
console.log(stringReturnTwo());


function caller(stalker) {
	if (typeof stalker == "function") {
		return "This is a function.";
	}
	if (typeof stalker != "function") {
		return "Not a function.";
	}
}




function myDoubleConsoleLog(x, y) {
    if (typeof x == "function" && typeof y == "function") {
        console.log(x());
        console.log(y());
    return;
    };
    console.log("Not functions!")
    return;
};

function testCase1(){
    console.log('Test case 1');
};

function testCase2(){
    console.log('Test case 2');
};

var testNum1 = "Patience";
var testNum2 = "Grasshopper!";

myDoubleConsoleLog(testCase1(), testCase2());
myDoubleConsoleLog(testNum1, testNum2);