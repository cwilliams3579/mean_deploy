var first_variable;
function firstFunction() {
	var first_variable;
	first_variable = "Not anymore";
	console.log(first_variable)

}
first_variable = "Yipee I was first!";
firstFunction();
console.log(first_variable);


var food;
function eat() {
	var food;
	food = "gone";
	console.log(food)
}
food = "half-chicken";
eat();
console.log(food);


var new_word;
function lastFunc() {
	var new_word;
	new_word = "old"
	console.log(new_word)
}
new_word = "NEW";
lastFunc();
console.log(new_word);
