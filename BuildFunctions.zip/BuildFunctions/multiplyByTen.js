function multipyByTen(x){
	return x*10;
};
console.log(multipyByTen(5));
